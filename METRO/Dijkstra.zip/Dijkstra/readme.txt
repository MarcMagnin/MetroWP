Author: Jeppe Andersen
Website: nocture.dk

Feel free to use this in any way you want!

